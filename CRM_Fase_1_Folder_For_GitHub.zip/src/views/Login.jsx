import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    if (username.toLowerCase() === 'admin') {
      if (password === 'SpaMonterrey') {
        localStorage.setItem('user', 'ADMIN');
        navigate('/home');
      } else {
        alert('Contraseña incorrecta');
      }
    } else {
      localStorage.setItem('user', username);
      navigate('/home');
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Ingresa tu nombre</h2>
      <input placeholder="Tu nombre" value={username} onChange={e => setUsername(e.target.value)} />
      {username.toLowerCase() === 'admin' && (
        <input type="password" placeholder="Contraseña" value={password} onChange={e => setPassword(e.target.value)} />
      )}
      <button onClick={handleLogin}>Entrar</button>
    </div>
  );
}

export default Login;
